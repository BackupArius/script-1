#!/bin/bash

DIA_ATUAL=`date --date="-0 day" +"%Y.%m.%d"`
HORAINICIAL=`date +%T`
VER=$(lsb_release -r| awk ' {print substr ($2,0,5) } ')
IPV4=$(cat /etc/network/interfaces | grep "address"|cut -c8-)
UPTIME=$(uptime -s)

####################################################
# Entrada do nro da loja e cliente
clear
echo [$(date --date="-0 day" +"%d/%m-%H:%M:%S")]".....Coletando informações do Cliente"
echo "----------------------------------------------------------------------"
echo
echo "                          ***** ATENÇÃO ******"
echo
echo "Insira o nome do cliente em minúsculo e sem espaços em branco"
echo "Exemplos: bombaiano, souzabueno, jdbrasilia, tateno_delihouse, teddy..."
echo
echo "Qual o Nome do Cliente"
echo
    read CLIENTE;
echo
echo   
echo "Qual o Numero da Loja. Ex. loja01"
echo
    read LOJA1;

clear
echo
echo [$(date --date="-0 day" +"%d/%m-%H:%M:%S")]".....Confira as infomações do cliente" 
echo "------------------------------------------------------------------------------"
echo 
echo
echo "Nome do Cliente: ${CLIENTE}"
echo
echo "Loja: ${LOJA1}"
echo
echo
echo
echo "Estão corretas? Responda s/n e tecle Enter."
    read CONFIRME;

## Solicitando a confirmação das infomações
if [ ${CONFIRME} == n ]; 

	then
		clear
		echo "........................................"
		echo
		echo "Reinicie o Processo..."
		echo
		echo "Execute novamente o Script ./criabkp.sh"
		echo
		echo "........................................"
		echo
		exit 0
	
	else
		clear
		echo
		echo [$(date --date="-0 day" +"%d/%m-%H:%M:%S")]".....Continuando a instalação"
		echo "----------------------------------------------------------------------"
		echo -n "Coletando informações.."
		sleep 3
		echo -n ".."
		sleep 1
		echo "...."
		echo "Ubuntu ${VER}"
		sleep 2
		echo "IP ${IPV4}"
		echo -n "Processador  "
		cat /proc/cpuinfo | grep -m1 "model name"|cut -c14-
		#echo -n "Memória"
		echo "Máquina Ativa desde :   ${UPTIME}"
		echo "Espaço em Disco:"
		df -h|egrep -v '(tmpfs|udev)'
		sleep 5
		
fi


mkdir -p /u01/backup/${CLIENTE}/${LOJA1}/licenca

######################################################
# Instala o rclone
echo
echo [$(date --date="-0 day" +"%d/%m-%H:%M:%S")]".....Instalando o RClone"
echo "----------------------------------------------------------------------"

sleep 3

if [ -f /usr/bin/rclone ] 
	then
		
		echo
		echo "====================================="
		echo "RClone já está instalado"
		echo "Continuando a instalação do Backup..."
		echo "====================================="
		echo
		sleep 5
		
	else
	
		wget -O rclone.deb --no-check-certificate https://downloads.rclone.org/v1.59.2/rclone-v1.59.2-linux-amd64.deb && dpkg -i rclone.deb
fi


echo
echo [$(date --date="-0 day" +"%d/%m-%H:%M:%S")]".....Configurando o RClone"
echo "----------------------------------------------------------------------"

mkdir -p /root/.config/rclone/
cp -vf /tmp/rclone.conf /root/.config/rclone/
cat /root/.config/rclone/rclone.conf


###########################################
# Cria o arquivo de bkpgeral.sh
#
echo
echo [$(date --date="-0 day" +"%d/%m-%H:%M:%S")]".....Criando Arquivos e Diretorios"
echo "----------------------------------------------------------------------"
sleep 3

rm -f /u01/bkpgeral.sh

#mkdir -p /u01/backup/${CLIENTE}/${LOJA1}/licenca

	touch /u01/bkpgeral.sh && cd /u01/ 

	echo '#################################################' >> bkpgeral.sh 
	echo '# Script da Backup e envio de arquivos para o FTP CRE' >> bkpgeral.sh
	echo '# Data: 27/02/2019' >> bkpgeral.sh 
    echo '# Autores Jasiel / Kelberson / Cleber' >> bkpgeral.sh 
    echo '################################################' >> bkpgeral.sh
    echo '#' >> bkpgeral.sh
    echo '#' >> bkpgeral.sh
    echo '#### Variaveis de datas' >> bkpgeral.sh
    echo 'DIA_ATUAL=`date --date="-0 day" +"%Y.%m.%d"`' >> bkpgeral.sh
    echo 'BKP_OLD=`date --date="-5 day" +"%Y.%m.%d"`' >> bkpgeral.sh
    echo '#' >> bkpgeral.sh
    echo '#' >> bkpgeral.sh
    echo '#### Configuracoes do Cliente' >> bkpgeral.sh
    echo 'EMPRESA="'${CLIENTE}'"' >> bkpgeral.sh
    echo 'LOJA="'${LOJA1}'"' >> bkpgeral.sh
    echo 'DIR_BKP="/u01/backup"' >> bkpgeral.sh
    echo 'DIR_BKP2=/u01/backup/${EMPRESA}/${LOJA}' >> bkpgeral.sh
	
# wget -c ftp://cre:suporte@ftp.cre.com.br:2321/pub/cre/kelberson/install_bkp*

cat /tmp/install_bkp >> /u01/bkpgeral.sh

#########################################################
# Insere a linha nos Crontabs
echo
echo [$(date --date="-0 day" +"%d/%m-%H:%M:%S")]".....Agendando Tarefa de Backup no Crontab"
echo "----------------------------------------------------------------------"
sleep 3

CRON=$(grep "bkpgeral.sh" /etc/crontab)

if [ -n "$CRON" ]
	
	then
		
		echo
		echo "====================================="
		echo "O agendamento ja existe"
		echo "Continuando a instalação do Backup..."
		echo "====================================="
		echo
		sleep 5
	
	else

		echo '30 11	* * *	root	/u01/./bkpgeral.sh' >> /etc/crontab
		service cron restart

fi

tail /etc/crontab

#########################################################
# Insere a linha no samba
echo
echo [$(date --date="-0 day" +"%d/%m-%H:%M:%S")]".....Criando compartilhamento no Samba"
echo "----------------------------------------------------------------------"
sleep 3


SMB=$(grep "/u01/backup" /etc/samba/smb.conf)

if [ -n "${SMB}" ]

	then
	
		echo
		echo "====================================="
		echo "A configuracao Samba ja existe"
		echo "Continuando a instalação do Backup..."
		echo "====================================="
		echo
		sleep 5

	else

		echo '#' >> /etc/samba/smb.conf
		echo '#' >> /etc/samba/smb.conf
		echo '[backup]' >> /etc/samba/smb.conf
		echo 'path = /u01/backup' >> /etc/samba/smb.conf
		echo 'writable = yes' >> /etc/samba/smb.conf
		echo 'public = yes' >> /etc/samba/smb.conf
		echo 'printable = no' >> /etc/samba/smb.conf
		echo 'create mask = 0666' >> /etc/samba/smb.conf
		echo 'directory mask = 0777' >> /etc/samba/smb.conf
		service smbd restart

fi       

echo
echo [$(date --date="-0 day" +"%d/%m-%H:%M:%S")]".....Executando backup pela primeira vez"
echo "----------------------------------------------------------------------"
sleep 3

chmod +x /u01/bkpgeral.sh
chmod +x /u01/bkpgeral01.sh

/u01/bkpgeral01.sh
/u01/bkpgeral.sh
rm -vf /u01/bkpgeral01.sh

echo
echo [$(date --date="-0 day" +"%d/%m-%H:%M:%S")]".....Tarefa de Backup criada"
echo "----------------------------------------------------------------------"
echo
echo "Com sussesso..."

sleep 3
clear

## script para calcular o tempo gasto no processo de backup
	HORAFINAL=`date +%T`
	HORAINICIAL01=$(date -u -d "$HORAINICIAL" +"%s")
	HORAFINAL01=$(date -u -d "$HORAFINAL" +"%s")
	TEMPO=`date -u -d "0 $HORAFINAL01 sec - $HORAINICIAL01 sec" +"%H:%M:%S"`
	echo
	echo [$(date --date="-0 day" +"%d/%m-%H:%M:%S")]".....Finalizando $0 "
	echo "----------------------------------------------------------------------"
	echo "Tempo total gasto na execução $TEMPO"

## Finalizando
echo
echo
date
echo
echo "Developed by Kelberson Abreu | Arius Sistemas"
echo
echo
echo
echo
